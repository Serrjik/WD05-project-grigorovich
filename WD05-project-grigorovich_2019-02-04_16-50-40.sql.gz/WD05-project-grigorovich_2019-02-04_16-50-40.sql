#SXD20|20011|50719|70107|2019.02.04 16:50:40|WD05-project-grigorovich|utf8|2|6|
#TA about`0`16384|users`6`16384
#EOH

#	TC`about`utf8_general_ci	;
CREATE TABLE `about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TC`users`utf8_general_ci	;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(191) DEFAULT NULL,
  `name` varchar(191) DEFAULT NULL,
  `surname` varchar(191) DEFAULT NULL,
  `country` varchar(191) DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `avatar` varchar(191) DEFAULT NULL,
  `avatar_small` varchar(191) DEFAULT NULL,
  `recovery_code` varchar(191) DEFAULT NULL,
  `recovery_code_times` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8	;
#	TD`users`utf8_general_ci	;
INSERT INTO `users` VALUES 
(1,'info@uac.com','$2y$10$nqPT0V3S6yN2O7m.C3pDA.qW0XchH/HtwidJpLrffNNdcdaKWgbOK','admin','Сергей','Григорович','Беларусь','Березино','979656711358.jpg','48-979656711358.jpg','kFygG5z2UduJ6ew',0),
(18,'mail@mail.ru','$2y$10$RTTcbKp45y.niAtD75Qm0egKEAmEMULIsr9KgALby4NUy.lYCkngG','user',\N,\N,\N,\N,\N,\N,\N,\N),
(19,'info3@uac.com','$2y$10$XG47VIsw4qWGPLlL3HAJUee0Q9s1rhv1cSZhMXkIQYn656DCV5Se2','user','User3','Третьяков','Россия','Волгоград','528185697112.jpg','48-528185697112.jpg','0h5D4KQSLZm792k',3),
(23,'test@test.com','$2y$10$UT21LxyqtFC/RX.NFo4Jhes3mVidnJR2LJtd4iVrPHYwZZEK8HI8y','user',\N,\N,\N,\N,\N,\N,\N,\N),
(26,'frank@telecom.ru','$2y$10$u/tvx/.r8T8lm83Qbf4zNe/sXJ3lXIQwmNknN1Pee9FYstAbcKc0u','user','Фрэнк','Давыдов','Россия','Питер','324452254963.jpg','48-324452254963.jpg',\N,\N),
(28,'delgardo@squad.com','$2y$10$QWXxfSNdUH.65SKNgv3PQO4gA9R4n.DX/aLgQcxBJIPh82jMWNNIu','user','Дельгардо','Испанец','Испания','','857267536894.jpg','48-857267536894.jpg',\N,\N)	;
