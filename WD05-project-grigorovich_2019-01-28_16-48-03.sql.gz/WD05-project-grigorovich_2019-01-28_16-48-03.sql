#SXD20|20011|50719|70107|2019.01.28 16:48:03|WD05-project-grigorovich|utf8|1|0|
#TA about`0`16384
#EOH

#	TC`about`utf8_general_ci	;
CREATE TABLE `about` (
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
